// usado ia chat gpt
// Um simulador de rota otimizada para transporte de alimentos entre o campo e a cidade,
let truckX, truckY;
let score = 0;
let truckEmoji = "🚛";
let fieldEmoji = "🏞️";
let cityEmoji = "🏙️";
let obstacleEmoji = "🚧";
let cornEmoji = "🌽";

let obstacles = [];
let corns = [];
let initialX, initialY;
let goalX, goalY;
let farmX, farmY;

let startTime;
let elapsedTime = 0;
let finalTime = 0;
let timeLimit = 10;

const confettiCount = 100;
let confettis = [];

let gameState = "start"; // "start", "playing", "won", "gameOver"

function setup() {
  createCanvas(800, 800);

  initialX = width - 100;
  initialY = height / 4;
  truckX = initialX;
  truckY = initialY;

  goalX = 100;
  goalY = height / 2;

  farmX = width / 2;
  farmY = height - 150;

  textSize(48);
  textAlign(CENTER, CENTER);

  obstacles = [
    { x: 250, y: 100 },
    { x: 400, y: 300 },
    { x: 600, y: 150 }
  ];

  corns = [
    { x: 300, y: 200, collected: false },
    { x: 150, y: 250, collected: false },
    { x: 500, y: 100, collected: false },
    { x: 700, y: 250, collected: false }
  ];

  startTime = millis();

  for (let i = 0; i < confettiCount; i++) {
    confettis.push({
      x: random(width),
      y: random(-height, 0),
      size: random(5, 10),
      speed: random(2, 5),
      color: color(random(255), random(255), random(255))
    });
  }
}

function draw() {
  background(180, 230, 180);

  if (gameState === "start") {
    drawStartScreen();
  } else if (gameState === "playing") {
    playGame();
  } else if (gameState === "won") {
    drawWinScreen();
  } else if (gameState === "gameOver") {
    drawGameOverScreen();
  }
}

function drawStartScreen() {
  textAlign(CENTER, CENTER);
  fill(0);
  textSize(50);
  text("🚛 Entrega na Cidade 🚛", width / 2, height / 2 - 100);

  textSize(28);
  text("Use as setas ⬆️⬇️⬅️➡️ para mover", width / 2, height / 2);
  text("Colete os 🌽 e evite os 🚧", width / 2, height / 2 + 40);
  text("Leve o caminhão até a cidade 🏙️", width / 2, height / 2 + 80);

  textSize(32);
  fill(50, 100, 200);
  text("Pressione ENTER para começar", width / 2, height / 2 + 150);
}

function playGame() {
  elapsedTime = (millis() - startTime) / 1000;
  if (elapsedTime >= timeLimit) {
    gameState = "gameOver";
  }

  // Estrada curva
  stroke(0);
  strokeWeight(4);
  noFill();
  beginShape();
  curveVertex(initialX, initialY);
  curveVertex(initialX, initialY);
  curveVertex(600, 150);
  curveVertex(400, 300);
  curveVertex(250, 100);
  curveVertex(goalX, goalY);
  curveVertex(goalX, goalY);
  endShape();

  // Fazendas e cidade
  noStroke();
  fill(0);
  textSize(48);
  text(fieldEmoji, initialX, initialY - 60);
  text(fieldEmoji, farmX, farmY);

  textSize(64);
  text(cityEmoji, goalX, goalY + 80);

  // Obstáculos
  textSize(48);
  for (let obs of obstacles) {
    text(obstacleEmoji, obs.x, obs.y);
  }

  // Milhos
  for (let corn of corns) {
    if (!corn.collected) {
      text(cornEmoji, corn.x, corn.y);
      if (dist(truckX, truckY, corn.x, corn.y) < 40) {
        corn.collected = true;
        score += 1;
      }
    }
  }

  // Caminhão
  text(truckEmoji, truckX, truckY);

  // Colisão com obstáculos
  for (let obs of obstacles) {
    if (dist(truckX, truckY, obs.x, obs.y) < 40) {
      gameState = "gameOver";
    }
  }

  // Chegou no destino
  if (dist(truckX, truckY, goalX, goalY) < 50) {
    gameState = "won";
    finalTime = elapsedTime;
  }

  // Placar e tempo
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  let displayedTime = max(0, (timeLimit - floor(elapsedTime)));
  text(`🌽 Milhos: ${score}`, 10, 10);
  text(`⏱️ Tempo: ${displayedTime.toFixed(0)}s`, 10, 40);
}

function drawWinScreen() {
  textAlign(CENTER, CENTER);
  for (let c of confettis) {
    fill(c.color);
    noStroke();
    ellipse(c.x, c.y, c.size);
    c.y += c.speed;
    if (c.y > height) {
      c.y = random(-height, 0);
      c.x = random(width);
    }
  }

  fill(0, 150, 0);
  textSize(48);
  text("🎉 Entrega concluída com sucesso!", width / 2, height / 2);
  textSize(24);
  text(`🌽 Milhos coletados: ${score}`, width / 2, height / 2 + 50);
  text(`⏱️ Tempo: ${finalTime.toFixed(0)}s`, width / 2, height / 2 + 90);

  textSize(24);
  fill(50, 100, 200);
  text("Pressione ENTER para jogar novamente", width / 2, height / 2 + 140);
}

function drawGameOverScreen() {
  textAlign(CENTER, CENTER);
  fill(255, 0, 0);
  textSize(32);
  if (elapsedTime >= timeLimit) {
    text("⏰ Tempo esgotado! Fim de jogo!", width / 2, height / 2);
  } else {
    text("💥 Colisão! Fim de jogo!", width / 2, height / 2);
  }

  textSize(24);
  fill(50, 100, 200);
  text("Pressione ENTER para tentar novamente", width / 2, height / 2 + 60);
}

function keyPressed() {
  if (gameState === "start" || gameState === "gameOver" || gameState === "won") {
    if (keyCode === ENTER) {
      restartGame();
      gameState = "playing";
    }
  }

  if (gameState === "playing") {
    const step = 20;
    if (keyCode === LEFT_ARROW) truckX -= step;
    else if (keyCode === RIGHT_ARROW) truckX += step;
    else if (keyCode === UP_ARROW) truckY -= step;
    else if (keyCode === DOWN_ARROW) truckY += step;
  }
}

function restartGame() {
  truckX = initialX;
  truckY = initialY;
  score = 0;
  startTime = millis();
  elapsedTime = 0;

  for (let corn of corns) {
    corn.collected = false;
  }
}
